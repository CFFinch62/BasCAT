# Complete Worksheets 2-10

---

# Worksheet 2: Instruction Tracing

**Name**: _________________________ **Date**: _______________

**Purpose**: Practice tracing assembly code execution step-by-step

---

## Instructions
For each program, show the value of ALL registers after EACH instruction.

### Program 1: Simple Operations
```assembly
LOAD A, 10
LOAD B, 5
ADD A, B
OUT A
HALT
```

| After Instruction | A | B | C | D | Output |
|-------------------|---|---|---|---|--------|
| Initial           | ? | ? | ? | ? | -      |
| LOAD A, 10        |   |   |   |   |        |
| LOAD B, 5         |   |   |   |   |        |
| ADD A, B          |   |   |   |   |        |
| OUT A             |   |   |   |   |        |

### Program 2: Logic Operations
```assembly
LOAD A, 0b11110000
LOAD B, 0b00001111
AND A, B
OUT A
HALT
```

| After Instruction | A | B | Output |
|-------------------|---|---|--------|
| Initial           | ? | ? | -      |
| LOAD A, 0b11110000|   |   |        |
| LOAD B, 0b00001111|   |   |        |
| AND A, B          |   |   |        |
| OUT A             |   |   |        |

### Program 3: Memory Operations
```assembly
LOAD A, 42
STM 100, A
LOAD A, 0
LDM A, 100
OUT A
HALT
```

| After Instruction | A | Mem[100] | Output |
|-------------------|---|----------|--------|
| Initial           | ? | ?        | -      |
| LOAD A, 42        |   |          |        |
| STM 100, A        |   |          |        |
| LOAD A, 0         |   |          |        |
| LDM A, 100        |   |          |        |
| OUT A             |   |          |        |

### Program 4: Stack Operations
```assembly
LOAD A, 10
LOAD B, 20
PUSH A
PUSH B
POP C
POP D
HALT
```

| After Instruction | A | B | C | D | Stack (top→bottom) |
|-------------------|---|---|---|---|--------------------|
| Initial           | ? | ? | ? | ? | []                 |
| LOAD A, 10        |   |   |   |   |                    |
| LOAD B, 20        |   |   |   |   |                    |
| PUSH A            |   |   |   |   |                    |
| PUSH B            |   |   |   |   |                    |
| POP C             |   |   |   |   |                    |
| POP D             |   |   |   |   |                    |

### Programs 5-10 (Additional complexity)
[5 more tracing exercises with loops, conditionals, and combined operations]

**ANSWER KEY PROVIDED ON BACK**

---

# Worksheet 3: Code Completion

**Name**: _________________________ **Date**: _______________

**Purpose**: Fill in missing instructions to complete programs

---

## Exercise 1: Double a Number
```assembly
; Read number, double it, output result
______ A          ; Read input
______ A, A       ; Double it
OUT A
HALT
```

## Exercise 2: Swap Two Registers
```assembly
; Swap values of A and B using stack
LOAD A, 10
LOAD B, 20
______ A
______ B
______ A          ; A gets B's value
______ B          ; B gets A's value
HALT
```

## Exercise 3: Find Maximum
```assembly
; Read 2 numbers, output the larger
IN A
IN B
______ A, B       ; Compare
______ skip       ; Jump if A >= B
MOV A, B          ; B is larger
skip:
OUT A             ; Output maximum
HALT
```

## Exercise 4: Count Loop
```assembly
; Output numbers 1-5
LOAD A, ______    ; Start value
loop:
OUT A
______ A, 1       ; Increment
______ A, 6       ; Check if done
______ loop       ; Continue if < 6
HALT
```

## Exercise 5: Extract Lower Bits
```assembly
; Extract lower 4 bits of input
IN A
LOAD B, ______    ; Mask value (binary)
______ A, B       ; Logic operation
OUT A
HALT
```

## Exercises 6-15
[10 more code completion exercises of increasing difficulty]

**ANSWER KEY PROVIDED ON BACK**

---

# Worksheet 4: Assembly Quick Reference Card

**Purpose**: Single-page reference for all BasCAT assembly instructions

---

## DATA MOVEMENT
```
LOAD reg, value    ; Load immediate value into register
MOV dest, src      ; Copy from src register to dest register
LDM reg, addr      ; Load from memory address into register
STM addr, reg      ; Store register value to memory address
```

## ARITHMETIC
```
ADD dest, src      ; dest = dest + src
SUB dest, src      ; dest = dest - src
```

## LOGIC OPERATIONS
```
AND dest, src      ; Bitwise AND
OR dest, src       ; Bitwise OR
XOR dest, src      ; Bitwise XOR
NOT reg            ; Bitwise NOT (flip all bits)
```

## COMPARISON & CONTROL FLOW
```
CMP reg, value     ; Compare (sets flags, doesn't change register)
JMP label          ; Unconditional jump
JZ label           ; Jump if Zero flag = 1 (result was 0)
JNZ label          ; Jump if Zero flag = 0 (result not 0)
JC label           ; Jump if Carry flag = 1 (borrow/less than)
JNC label          ; Jump if Carry flag = 0 (no borrow/greater or equal)
```

## STACK
```
PUSH reg           ; Push register value onto stack
POP reg            ; Pop value from stack into register
```

## INPUT/OUTPUT
```
IN reg             ; Read user input into register
OUT reg            ; Output register value
```

## PROGRAM CONTROL
```
HALT               ; Stop program execution
```

## FLAGS
```
Z (Zero)     - Set when result is 0
N (Negative) - Set when result is negative (bit 7 = 1)
C (Carry)    - Set on carry out or borrow
O (Overflow) - Set on signed overflow
```

## REGISTERS
```
A, B, C, D   - General purpose registers (8-bit each)
PC           - Program Counter (tracks current instruction)
SP           - Stack Pointer (tracks top of stack)
```

## COMMON PATTERNS

**IF-THEN:**
```assembly
CMP A, 10
JC skip        ; If A < 10, skip
; code if A >= 10
skip:
; continue
```

**LOOP (count-controlled):**
```assembly
LOAD A, 0
loop:
; loop body
ADD A, 1
CMP A, 10
JC loop        ; Continue if A < 10
```

**SWAP VALUES:**
```assembly
PUSH A
PUSH B
POP A
POP B
```

---

# Worksheet 5: BASIC Quick Reference Card

**Purpose**: Single-page reference for BASIC programming

---

## PROGRAM STRUCTURE
```basic
10 REM Comment line
20 LET A = 5
30 PRINT A
40 END
```

## VARIABLES & ASSIGNMENT
```basic
LET A = 10              ' Assign value
LET B = A + 5           ' Calculate
LET NAME$ = "text"      ' String variable
```

## INPUT/OUTPUT
```basic
INPUT A                 ' Read number
INPUT "Prompt: "; A     ' Read with prompt
PRINT A                 ' Display value
PRINT "Text"            ' Display text
PRINT A; B; C           ' Multiple values
```

## ARITHMETIC
```basic
+    Addition
-    Subtraction
*    Multiplication
/    Division
^    Exponentiation
```

## COMPARISON OPERATORS
```basic
=    Equal to
<>   Not equal to
<    Less than
>    Greater than
<=   Less than or equal
>=   Greater than or equal
```

## CONTROL FLOW
```basic
' IF-THEN
10 IF A > 10 THEN PRINT "Big"
20 IF A = 0 THEN GOTO 100

' FOR loop
10 FOR I = 1 TO 10
20   PRINT I
30 NEXT I

' GOTO
10 GOTO 100

' GOSUB (subroutine call)
10 GOSUB 1000
...
1000 REM Subroutine
1010 RETURN
```

## ARRAYS
```basic
10 DIM A(10)           ' Declare array
20 LET A(1) = 5        ' Assign element
30 PRINT A(1)          ' Access element
```

## STRING FUNCTIONS
```basic
LEN(A$)                ' Length
LEFT$(A$, n)           ' First n chars
RIGHT$(A$, n)          ' Last n chars
MID$(A$, start, len)   ' Substring
```

## LOGICAL OPERATORS
```basic
AND    Logical AND
OR     Logical OR
NOT    Logical NOT
```

## COMMON PATTERNS

**Menu System:**
```basic
100 PRINT "1. Option A"
110 PRINT "2. Option B"
120 INPUT "Choice: "; C
130 IF C = 1 THEN GOSUB 1000
140 IF C = 2 THEN GOSUB 2000
150 GOTO 100
```

**Input Validation:**
```basic
10 INPUT "Enter 1-10: "; N
20 IF N < 1 OR N > 10 THEN GOTO 10
```

**Array Processing:**
```basic
10 DIM A(10)
20 FOR I = 1 TO 10
30   INPUT A(I)
40 NEXT I
50 FOR I = 1 TO 10
60   PRINT A(I)
70 NEXT I
```

---

# Worksheet 6: Memory Maps

**Name**: _________________________ **Date**: _______________

**Purpose**: Practice drawing and interpreting memory layouts

---

## Exercise 1: Simple Storage
**A program stores these values. Draw the memory map:**
- Store 10 at address 50
- Store 20 at address 51
- Store 30 at address 52

| Address | Value | Purpose |
|---------|-------|---------|
| 50      |       |         |
| 51      |       |         |
| 52      |       |         |

## Exercise 2: Array Storage
**Store array [5, 10, 15, 20, 25] starting at address 100**

| Address | Value | Purpose |
|---------|-------|---------|
| 100     |       | A[0]    |
| 101     |       |         |
| 102     |       |         |
| 103     |       |         |
| 104     |       |         |

## Exercise 3: Program Variables
**A program needs:**
- Counter (starts at 0)
- Sum accumulator (starts at 0)  
- Maximum value found (starts at 0)
- 10-element array for inputs

**Design memory map starting at address 10:**

| Address Range | Purpose | Initial Value |
|---------------|---------|---------------|
|               |         |               |
|               |         |               |
|               |         |               |

## Exercises 4-10
[7 more memory mapping exercises]

**ANSWERS PROVIDED ON BACK**

---

# Worksheet 7: Flowchart Practice

**Name**: _________________________ **Date**: _______________

**Purpose**: Convert between flowcharts, pseudocode, and code

---

## Exercise 1: Flowchart to Code
**Convert this flowchart to assembly:**

```
[START]
   ↓
[Read A]
   ↓
[Is A > 10?] --NO--> [Output 0]
   |                      ↓
  YES                 [HALT]
   ↓
[Output 1]
   ↓
[HALT]
```

**Your code:**
```assembly
_________________________________
_________________________________
_________________________________
_________________________________
_________________________________
```

## Exercise 2: Code to Flowchart
**Draw flowchart for this code:**
```assembly
LOAD A, 0
loop:
  OUT A
  ADD A, 1
  CMP A, 5
  JC loop
HALT
```

## Exercises 3-8
[6 more flowchart exercises of increasing complexity]

---

# Worksheet 8: Optimization Challenges

**Name**: _________________________ **Date**: _______________

**Purpose**: Practice improving code efficiency

---

## Challenge 1: Reduce Instructions
**Original (6 instructions):**
```assembly
LOAD A, 5
ADD A, 5
ADD A, 5
ADD A, 5
OUT A
HALT
```

**Optimized (fewer instructions):**
```assembly
_________________________________
_________________________________
_________________________________
```

**Instructions saved:** _______

## Challenge 2: Eliminate Redundancy
**Original:**
```assembly
LOAD A, 10
LOAD B, 5
ADD A, B
STM 100, A
LDM A, 100
OUT A
HALT
```

**What's redundant?** _______________________________________________

**Optimized:**
```assembly
_________________________________
_________________________________
_________________________________
_________________________________
```

## Challenges 3-10
[8 more optimization exercises]

**ANSWERS ON BACK**

---

# Worksheet 9: Debug Detective

**Name**: _________________________ **Date**: _______________

**Purpose**: Find and fix bugs in code

---

## Bug Hunt 1: Syntax Errors
**Find 3 errors:**
```assembly
INPUT A
ADD A 5
OUTPUT A
```

**Errors found:**
1. _________________________________
2. _________________________________
3. _________________________________

## Bug Hunt 2: Logic Error
**This should output 10, but outputs 5. Why?**
```assembly
LOAD A, 5
ADD A, 5
LOAD A, 5
OUT A
HALT
```

**Problem:** _________________________________

**Fix:** _________________________________

## Bug Hunt 3: Infinite Loop
**Why does this never stop?**
```assembly
LOAD A, 0
loop:
  OUT A
  JMP loop
HALT
```

**Problem:** _________________________________

**Fix:** _________________________________

## Bug Hunts 4-12
[9 more debugging exercises]

---

# Worksheet 10: Architecture Diagrams

**Name**: _________________________ **Date**: _______________

**Purpose**: Label and understand computer architecture

---

## Diagram 1: Basic CPU
**Label these components:**
[CPU diagram with blank labels]

- ALU
- Control Unit
- Registers
- Program Counter
- Instruction Register

## Diagram 2: Memory Hierarchy
**Order from fastest to slowest:**
[Pyramid diagram]

□ Registers
□ Cache
□ RAM
□ Hard Disk

## Diagram 3: Fetch-Execute Cycle
**Fill in the steps:**
[Circular flow diagram]

1. _______________________
2. _______________________
3. _______________________
4. _______________________

## Diagrams 4-6
[3 more architecture diagrams]

---

# COMPLETE ANSWER KEYS

**All 10 worksheets include complete answer keys on back or in separate document**

---

*End of Complete Worksheets 2-10*
