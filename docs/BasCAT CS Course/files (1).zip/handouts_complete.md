# Complete Student Handouts 1-10

---

# Handout 1: Assembly Quick Reference Card

**PRINT ON CARDSTOCK - LAMINATE - ONE PER STUDENT**

```
╔════════════════════════════════════════════════════╗
║         BASCAT ASSEMBLY REFERENCE CARD             ║
║                                                    ║
║  DATA MOVEMENT                                     ║
║  LOAD A, 10     Put 10 into register A           ║
║  MOV B, A       Copy A to B                       ║
║  LDM A, 100     Load from address 100 into A     ║
║  STM 100, A     Store A at address 100           ║
║                                                    ║
║  ARITHMETIC                                        ║
║  ADD A, B       A = A + B                         ║
║  SUB A, B       A = A - B                         ║
║                                                    ║
║  LOGIC                                             ║
║  AND A, B       Bitwise AND                       ║
║  OR A, B        Bitwise OR                        ║
║  XOR A, B       Bitwise XOR                       ║
║  NOT A          Flip all bits in A                ║
║                                                    ║
║  COMPARISON                                        ║
║  CMP A, 10      Compare A with 10 (sets flags)   ║
║                                                    ║
║  JUMPS                                             ║
║  JMP label      Always jump                       ║
║  JZ label       Jump if Zero (result = 0)        ║
║  JNZ label      Jump if Not Zero                 ║
║  JC label       Jump if Carry (less than)        ║
║  JNC label      Jump if No Carry (≥)             ║
║                                                    ║
║  STACK                                             ║
║  PUSH A         Put A on stack                    ║
║  POP A          Get top of stack into A          ║
║                                                    ║
║  I/O                                               ║
║  IN A           Read user input into A           ║
║  OUT A          Display value of A               ║
║                                                    ║
║  CONTROL                                           ║
║  HALT           Stop program                      ║
║                                                    ║
║  REGISTERS: A, B, C, D (8-bit each)              ║
║                                                    ║
║  FLAGS:                                            ║
║  Z - Zero (result = 0)                           ║
║  C - Carry (borrow/less than)                    ║
║  N - Negative (bit 7 = 1)                        ║
║  O - Overflow                                     ║
║                                                    ║
╚════════════════════════════════════════════════════╝
```

---

# Handout 2: BASIC Quick Reference Card

**PRINT ON CARDSTOCK - LAMINATE - ONE PER STUDENT**

```
╔════════════════════════════════════════════════════╗
║            BASIC REFERENCE CARD                    ║
║                                                    ║
║  STRUCTURE                                         ║
║  10 REM Comment                                   ║
║  20 LET A = 5                                     ║
║  30 PRINT A                                       ║
║  40 END                                            ║
║                                                    ║
║  VARIABLES                                         ║
║  LET A = 10      Numeric variable                ║
║  LET N$ = "Hi"   String variable                 ║
║                                                    ║
║  INPUT/OUTPUT                                      ║
║  INPUT A                                          ║
║  INPUT "Prompt: "; A                             ║
║  PRINT A                                          ║
║  PRINT "Text"                                     ║
║  PRINT A; B; C                                    ║
║                                                    ║
║  OPERATORS                                         ║
║  + - * / ^       Math operations                 ║
║  = <> < > <= >=  Comparisons                     ║
║  AND OR NOT      Logical                         ║
║                                                    ║
║  CONTROL FLOW                                      ║
║  IF A > 10 THEN PRINT "Big"                      ║
║  IF A = 0 THEN GOTO 100                          ║
║  GOTO 100        Jump to line                    ║
║                                                    ║
║  LOOPS                                             ║
║  FOR I = 1 TO 10                                 ║
║    PRINT I                                        ║
║  NEXT I                                           ║
║                                                    ║
║  FOR I = 0 TO 100 STEP 10                        ║
║    ' code                                         ║
║  NEXT I                                           ║
║                                                    ║
║  SUBROUTINES                                       ║
║  GOSUB 1000      Call subroutine                 ║
║  ...                                              ║
║  1000 REM Sub                                     ║
║  1010 RETURN                                      ║
║                                                    ║
║  ARRAYS                                            ║
║  DIM A(10)       Declare array                   ║
║  LET A(1) = 5    Assign element                  ║
║  PRINT A(1)      Access element                  ║
║                                                    ║
║  STRINGS                                           ║
║  LEN(A$)         Length                          ║
║  LEFT$(A$, n)    First n chars                   ║
║  RIGHT$(A$, n)   Last n chars                    ║
║                                                    ║
╚════════════════════════════════════════════════════╝
```

---

# Handout 3: Binary Conversion Chart

**PRINT ON CARDSTOCK - LAMINATE**

```
╔═══════════════════════════════════════════════════════╗
║          BINARY CONVERSION REFERENCE                  ║
║                                                       ║
║  8-BIT BINARY POSITIONS:                             ║
║                                                       ║
║  Bit:    7    6    5    4    3    2    1    0       ║
║  Value: 128  64   32   16   8    4    2    1        ║
║                                                       ║
║  Example: 01001011                                    ║
║           0·128 + 1·64 + 0·32 + 0·16 +              ║
║           1·8 + 0·4 + 1·2 + 1·1 = 75                ║
║                                                       ║
║  COMMON VALUES:                                       ║
║  Dec  | Binary   | Hex | Note                       ║
║  -----|----------|-----|----------------------------║
║  0    | 00000000 | 00  | All bits off              ║
║  1    | 00000001 | 01  | Bit 0                     ║
║  2    | 00000010 | 02  | Bit 1                     ║
║  4    | 00000100 | 04  | Bit 2                     ║
║  8    | 00001000 | 08  | Bit 3                     ║
║  15   | 00001111 | 0F  | Lower nibble              ║
║  16   | 00010000 | 10  | Bit 4                     ║
║  32   | 00100000 | 20  | Bit 5                     ║
║  64   | 01000000 | 40  | Bit 6                     ║
║  127  | 01111111 | 7F  | Max positive (signed)     ║
║  128  | 10000000 | 80  | Bit 7                     ║
║  240  | 11110000 | F0  | Upper nibble              ║
║  255  | 11111111 | FF  | All bits on               ║
║                                                       ║
║  QUICK CONVERSIONS:                                   ║
║  Decimal → Binary:                                    ║
║  1. Divide by 2 repeatedly                           ║
║  2. Write remainders right to left                   ║
║                                                       ║
║  Binary → Decimal:                                    ║
║  1. Multiply each bit by its position value         ║
║  2. Add all results                                  ║
║                                                       ║
║  NIBBLES:                                             ║
║  Upper nibble = bits 4-7 (left 4 bits)             ║
║  Lower nibble = bits 0-3 (right 4 bits)            ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
```

---

# Handout 4: Flags Reference Guide

**PRINT ON CARDSTOCK - LAMINATE**

```
╔════════════════════════════════════════════════════════╗
║              CPU FLAGS REFERENCE                       ║
║                                                        ║
║  FLAGS IN BASCAT:                                     ║
║                                                        ║
║  Z - ZERO FLAG                                        ║
║  Set when: Result of operation equals 0              ║
║  Example: SUB A, A → Z = 1 (result is 0)            ║
║  Use: Check if two values are equal                  ║
║                                                        ║
║  C - CARRY FLAG                                       ║
║  Set when: Borrow needed (unsigned comparison)       ║
║  Example: SUB A, B where A < B → C = 1               ║
║  Use: Check if A < B (less than)                     ║
║                                                        ║
║  N - NEGATIVE FLAG                                    ║
║  Set when: Bit 7 of result = 1                       ║
║  Example: Result = 10000000 → N = 1                  ║
║  Use: Check sign in signed arithmetic                ║
║                                                        ║
║  O - OVERFLOW FLAG                                    ║
║  Set when: Signed arithmetic overflow                ║
║  Example: 127 + 1 → O = 1                            ║
║  Use: Detect invalid signed results                  ║
║                                                        ║
║  HOW CMP USES FLAGS:                                  ║
║                                                        ║
║  CMP A, B (really does A - B but doesn't save)      ║
║                                                        ║
║  If A = B:  Z = 1, C = 0                            ║
║  If A < B:  Z = 0, C = 1                            ║
║  If A > B:  Z = 0, C = 0                            ║
║                                                        ║
║  CONDITIONAL JUMP TABLE:                              ║
║                                                        ║
║  Condition    | Jump If | Flag Status                ║
║  -------------|---------|---------------------------║
║  A = B        | JZ      | Z = 1                     ║
║  A ≠ B        | JNZ     | Z = 0                     ║
║  A < B        | JC      | C = 1                     ║
║  A >= B       | JNC     | C = 0                     ║
║  Always       | JMP     | Any                       ║
║                                                        ║
║  EXAMPLES:                                             ║
║                                                        ║
║  Check if A equals 10:                                ║
║    CMP A, 10                                          ║
║    JZ equal       ; Jump if A = 10                   ║
║                                                        ║
║  Check if A greater than 10:                          ║
║    CMP A, 10                                          ║
║    JNC bigger     ; Jump if A >= 10                  ║
║    ; Here if A < 10                                   ║
║                                                        ║
║  Check if A less than 10:                             ║
║    CMP A, 10                                          ║
║    JC smaller     ; Jump if A < 10                   ║
║                                                        ║
╚════════════════════════════════════════════════════════╝
```

---

# Handout 5: Memory Map Template

**PRINT ON PAPER - COPIES FOR EACH STUDENT**

```
╔════════════════════════════════════════════════════════╗
║              MEMORY MAP TEMPLATE                       ║
║                                                        ║
║  Program: _______________________  Date: __________   ║
║                                                        ║
║  Address  | Value | Purpose/Notes                     ║
║  ---------|-------|-----------------------------------║
║  0        |       |                                   ║
║  1        |       |                                   ║
║  2        |       |                                   ║
║  3        |       |                                   ║
║  4        |       |                                   ║
║  5        |       |                                   ║
║  6        |       |                                   ║
║  7        |       |                                   ║
║  8        |       |                                   ║
║  9        |       |                                   ║
║  10       |       |                                   ║
║  ...      |       |                                   ║
║  50       |       |                                   ║
║  ...      |       |                                   ║
║  100      |       |                                   ║
║  ...      |       |                                   ║
║  200      |       |                                   ║
║  ...      |       |                                   ║
║  254 (FE) |       | OUTPUT device                     ║
║  255 (FF) |       | INPUT device                      ║
║                                                        ║
║  REGISTER USAGE:                                       ║
║  A: _____________________________________________     ║
║  B: _____________________________________________     ║
║  C: _____________________________________________     ║
║  D: _____________________________________________     ║
║                                                        ║
║  STACK USAGE:                                          ║
║  ________________________________________________     ║
║                                                        ║
╚════════════════════════════════════════════════════════╝
```

---

# Handout 6: Program Planning Sheet

**PRINT ON PAPER - COPIES FOR EACH STUDENT**

```
╔════════════════════════════════════════════════════════╗
║           PROGRAM PLANNING WORKSHEET                   ║
║                                                        ║
║  PROGRAM NAME: ____________________________________   ║
║  DATE: __________  LANGUAGE: □ Assembly  □ BASIC     ║
║                                                        ║
║  1. PROBLEM STATEMENT                                  ║
║  What does this program need to do?                   ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║                                                        ║
║  2. INPUTS                                             ║
║  What data comes from the user?                       ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║                                                        ║
║  3. OUTPUTS                                            ║
║  What does the program display?                       ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║                                                        ║
║  4. ALGORITHM (Pseudocode or Steps)                   ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║                                                        ║
║  5. MEMORY/REGISTER PLAN                              ║
║  What variables/memory do you need?                   ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║                                                        ║
║  6. TEST CASES                                         ║
║  Input → Expected Output                              ║
║  ____________ → ____________                          ║
║  ____________ → ____________                          ║
║  ____________ → ____________                          ║
║                                                        ║
╚════════════════════════════════════════════════════════╝
```

---

# Handout 7: Debugging Checklist

**PRINT ON CARDSTOCK - LAMINATE**

```
╔════════════════════════════════════════════════════════╗
║            DEBUGGING CHECKLIST                         ║
║                                                        ║
║  WHEN YOUR PROGRAM DOESN'T WORK:                      ║
║                                                        ║
║  □ BASIC CHECKS                                        ║
║    □ Does it compile? (Check syntax errors)           ║
║    □ Does it have HALT? (Assembly)                    ║
║    □ Does it have END? (BASIC)                        ║
║    □ Are all labels spelled correctly?                ║
║                                                        ║
║  □ LOGIC CHECKS                                        ║
║    □ Trace through by hand - what should happen?     ║
║    □ Use Step Mode - watch registers change          ║
║    □ Check comparisons - using right jump?           ║
║    □ Check loop counter - incrementing?              ║
║    □ Check loop exit - right condition?              ║
║                                                        ║
║  □ DATA CHECKS                                         ║
║    □ Are inputs being read correctly?                ║
║    □ Are values stored where you think?              ║
║    □ Check memory addresses - right locations?       ║
║    □ Stack balanced? (PUSH = POP count)              ║
║                                                        ║
║  □ COMMON ASSEMBLY BUGS                                ║
║    □ Off-by-one in loop (CMP value wrong?)           ║
║    □ Wrong jump condition (JC vs JNC?)               ║
║    □ Register overwritten accidentally?              ║
║    □ Missing comma in instruction?                   ║
║    □ Infinite loop (no exit condition?)              ║
║                                                        ║
║  □ COMMON BASIC BUGS                                   ║
║    □ Forgetting LET in assignment?                   ║
║    □ Missing NEXT for FOR loop?                      ║
║    □ Missing RETURN for GOSUB?                       ║
║    □ Line numbers out of order?                      ║
║    □ GOTO to non-existent line?                      ║
║                                                        ║
║  DEBUGGING STRATEGIES:                                 ║
║  1. Test small parts separately                       ║
║  2. Add temporary OUTPUT statements                   ║
║  3. Use Step Mode to watch execution                  ║
║  4. Check one thing at a time                         ║
║  5. Ask: "What did I expect? What happened?"         ║
║                                                        ║
║  STILL STUCK?                                          ║
║  □ Explain your code to someone (or a rubber duck!)  ║
║  □ Take a break and come back fresh                  ║
║  □ Ask for help!                                      ║
║                                                        ║
╚════════════════════════════════════════════════════════╝
```

---

# Handout 8: Project Submission Checklist

**PRINT ON PAPER - ONE PER PROJECT**

```
╔════════════════════════════════════════════════════════╗
║         PROJECT SUBMISSION CHECKLIST                   ║
║                                                        ║
║  Name: _____________________  Project: ____________   ║
║                                                        ║
║  BEFORE YOU SUBMIT:                                    ║
║                                                        ║
║  □ CODE REQUIREMENTS                                   ║
║    □ All required features implemented                ║
║    □ Program compiles without errors                  ║
║    □ Program runs correctly                           ║
║    □ Handles all test cases                           ║
║    □ Ends properly (HALT or END)                      ║
║                                                        ║
║  □ CODE QUALITY                                        ║
║    □ Header complete (name, date, purpose)           ║
║    □ Comments explain what code does                  ║
║    □ Comments for each major section                  ║
║    □ Code organized logically                         ║
║    □ Clear variable/register usage                    ║
║                                                        ║
║  □ DOCUMENTATION                                       ║
║    □ Memory map included (if assembly)               ║
║    □ Algorithm explanation provided                   ║
║    □ User instructions (how to run)                   ║
║    □ Test results documented                          ║
║                                                        ║
║  □ TESTING                                             ║
║    □ Tested with normal inputs                        ║
║    □ Tested with edge cases (0, 255, etc)            ║
║    □ Tested with invalid inputs (if applicable)      ║
║    □ Results match expected outputs                   ║
║                                                        ║
║  □ FILE SUBMISSION                                     ║
║    □ Correct filename format                          ║
║    □ File saved in correct location                   ║
║    □ Backup copy made                                 ║
║                                                        ║
║  □ BONUS (If Attempted)                                ║
║    □ Extra features documented                        ║
║    □ Extra features tested                            ║
║    □ Extra features noted in header                   ║
║                                                        ║
║  NOTES FOR TEACHER:                                    ║
║  _________________________________________________    ║
║  _________________________________________________    ║
║                                                        ║
║  READY TO SUBMIT? → Turn in your work!               ║
║                                                        ║
╚════════════════════════════════════════════════════════╝
```

---

# Handout 9: Computer Architecture Poster

**PRINT ON 11x17 PAPER - LAMINATE - HANG ON WALL**

```
╔════════════════════════════════════════════════════════════╗
║              COMPUTER ARCHITECTURE                         ║
║                                                            ║
║  ┌────────────────────────────────────────────────────┐  ║
║  │                     CPU                            │  ║
║  │                                                    │  ║
║  │  ┌─────────────┐        ┌──────────────┐        │  ║
║  │  │   CONTROL   │        │  REGISTERS   │        │  ║
║  │  │    UNIT     │◄──────►│   A B C D    │        │  ║
║  │  │             │        │   PC  IR  SP  │        │  ║
║  │  └─────────────┘        └──────────────┘        │  ║
║  │         ▲                       ▲                 │  ║
║  │         │                       │                 │  ║
║  │         ▼                       ▼                 │  ║
║  │  ┌─────────────────────────────────┐            │  ║
║  │  │             ALU                  │            │  ║
║  │  │   (Arithmetic Logic Unit)       │            │  ║
║  │  │   ADD SUB AND OR XOR NOT        │            │  ║
║  │  └─────────────────────────────────┘            │  ║
║  │                                                    │  ║
║  └────────────────────────────────────────────────────┘  ║
║                          ▲▼                               ║
║  ┌────────────────────────────────────────────────────┐  ║
║  │                   MEMORY                           │  ║
║  │  Address 0    [    ]                              │  ║
║  │  Address 1    [    ]                              │  ║
║  │  ...          [    ]                              │  ║
║  │  Address 254  [    ] ← OUTPUT                     │  ║
║  │  Address 255  [    ] ← INPUT                      │  ║
║  └────────────────────────────────────────────────────┘  ║
║                                                            ║
║  FETCH-EXECUTE CYCLE:                                     ║
║  1. FETCH → Get instruction from memory                   ║
║  2. DECODE → Figure out what to do                        ║
║  3. EXECUTE → Do it (ALU, memory, etc)                    ║
║  4. INCREMENT → Move to next instruction                  ║
║  5. REPEAT                                                 ║
║                                                            ║
║  MEMORY HIERARCHY (Speed vs Size):                        ║
║  Registers    ◄─── Fastest, Smallest                      ║
║  Cache        ◄─── Very Fast, Small                       ║
║  RAM          ◄─── Fast, Medium                           ║
║  Hard Disk    ◄─── Slow, Huge                             ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

---

# Handout 10: Course Roadmap

**PRINT ON 11x17 PAPER - LAMINATE - HANG ON WALL**

```
╔════════════════════════════════════════════════════════════╗
║           BASCAT COURSE ROADMAP - 15 WEEKS                 ║
║                                                            ║
║  PHASE 1: ASSEMBLY PROGRAMMING (Weeks 1-6)               ║
║  ┌──────────────────────────────────────────────────┐    ║
║  │ Week 1: Data Movement (LOAD, MOV, STM, LDM)    │    ║
║  │ Week 2: Arithmetic & I/O (ADD, SUB, IN, OUT)   │    ║
║  │ Week 3: Logic Operations (AND, OR, XOR, NOT)    │    ║
║  │         ★ PROJECT 1: Calculator                  │    ║
║  │ Week 4: Control Flow (CMP, jumps, loops)        │    ║
║  │ Week 5: Stack & Procedures (PUSH, POP, LIFO)    │    ║
║  │ Week 6: Integration Project                      │    ║
║  │         ★ PROJECT 2: Game/Application            │    ║
║  └──────────────────────────────────────────────────┘    ║
║                                                            ║
║  PHASE 2: BASIC PROGRAMMING (Weeks 7-8)                  ║
║  ┌──────────────────────────────────────────────────┐    ║
║  │ Week 7: BASIC Basics (variables, I/O, control)  │    ║
║  │ Week 8: Advanced BASIC (arrays, subroutines)    │    ║
║  │         ☆ MIDTERM EXAM                           │    ║
║  └──────────────────────────────────────────────────┘    ║
║                                                            ║
║  PHASE 3: CONCEPTS (Weeks 9-10)                          ║
║  ┌──────────────────────────────────────────────────┐    ║
║  │ Week 9: Computer Architecture (CPU, memory)      │    ║
║  │ Week 10: Compiler Design (translation)           │    ║
║  │         ★ PROJECT 3: BASIC Application           │    ║
║  └──────────────────────────────────────────────────┘    ║
║                                                            ║
║  PHASE 4: ADVANCED (Weeks 11-14)                         ║
║  ┌──────────────────────────────────────────────────┐    ║
║  │ Week 11: Advanced Assembly & Optimization        │    ║
║  │ Week 12: Real-World Systems                      │    ║
║  │ Week 13: Advanced BASIC                          │    ║
║  │ Week 14: Integration & Comparison                │    ║
║  └──────────────────────────────────────────────────┘    ║
║                                                            ║
║  PHASE 5: CAPSTONE (Week 15)                             ║
║  ┌──────────────────────────────────────────────────┐    ║
║  │ Week 15: Final Projects & Presentations          │    ║
║  │         ★ PROJECT 4: Capstone                    │    ║
║  │         ☆ FINAL EXAM                             │    ║
║  └──────────────────────────────────────────────────┘    ║
║                                                            ║
║  KEY:                                                      ║
║  ★ = Major Project                                        ║
║  ☆ = Major Exam                                           ║
║                                                            ║
║  YOU WILL LEARN:                                          ║
║  ✓ How computers really work                              ║
║  ✓ Assembly and BASIC programming                         ║
║  ✓ Computer architecture                                  ║
║  ✓ How high-level languages work                          ║
║  ✓ When to use different languages                        ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
```

---

*End of Complete Student Handouts 1-10*

**PRINTING INSTRUCTIONS:**
- Handouts 1-4, 7, 9-10: Cardstock, laminate, reusable
- Handouts 5-6, 8: Regular paper, copies per student
- All handouts formatted for standard 8.5x11" or 11x17" paper
- Use color printing for Handouts 9-10 if possible (architecture diagrams)

