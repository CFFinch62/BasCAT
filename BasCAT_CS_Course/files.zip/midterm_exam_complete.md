# Midterm Exam: BasCAT Computer Architecture Course

**Name**: _________________________ **Date**: _______________

**Total Points**: 100 (50 written + 50 practical)
**Time**: 90 minutes (or split across 2 class periods)

---

# PART A: WRITTEN PORTION (50 points)

## Section 1: Assembly Fundamentals (20 points)

### Question 1: CPU Components (5 points)

**Label the CPU diagram below with these components:**
- ALU (Arithmetic Logic Unit)
- Control Unit  
- Registers (A, B, C, D)
- Program Counter (PC)
- Instruction Register (IR)

```
┌─────────────────────────────────┐
│                                 │
│  [____1____]  [____2____]      │
│                                 │
│  ┌───────┐                     │
│  │       │ ← 3. ____________   │
│  │  ALU  │                     │
│  │       │                     │
│  └───────┘                     │
│                                 │
│  [____4____]  [____5____]      │
│                                 │
└─────────────────────────────────┘

1. ______________________
2. ______________________
3. ______________________
4. ______________________
5. ______________________
```

### Question 2: Execution Trace (5 points)

**Trace this program's execution. Show register values after EACH instruction.**

```assembly
LOAD A, 10
LOAD B, 5
ADD A, B
SUB B, A
OUT B
HALT
```

| After Instruction | Register A | Register B | Output |
|-------------------|------------|------------|--------|
| Initial state     | ?          | ?          | -      |
| LOAD A, 10        |            |            |        |
| LOAD B, 5         |            |            |        |
| ADD A, B          |            |            |        |
| SUB B, A          |            |            |        |
| OUT B             |            |            |        |

### Question 3: Multiple Choice (10 points, 2 pts each)

**Circle the best answer.**

1. Which instruction loads a value FROM a memory address?
   a) LOAD
   b) LDM
   c) MOV
   d) GET

2. The stack follows which principle?
   a) FIFO (First In, First Out)
   b) LIFO (Last In, First Out)
   c) Random Access
   d) Sequential Access

3. After `CMP A, 10` with A=15, which jump will execute?
   a) JZ (Jump if Zero)
   b) JC (Jump if Carry)
   c) JNC (Jump if No Carry)
   d) None

4. What does the Z flag indicate?
   a) Zero result
   b) Negative result
   c) Overflow
   d) Carry

5. `AND 11110000 00001111` results in:
   a) 11111111
   b) 00000000
   c) 11110000
   d) 00001111

---

## Section 2: Logic and Control Flow (15 points)

### Question 4: Binary Logic (6 points, 2 pts each)

**Calculate the results:**

1. `10101010 OR 01010101` = ____________________

2. `11110000 XOR 11110000` = ____________________

3. `NOT 11001100` = ____________________

### Question 5: Control Flow Analysis (9 points)

**What does this code output for input values 7 and 12?**

```assembly
IN A               ; User enters 7
IN B               ; User enters 12
CMP A, 10
JNC skip
LOAD C, 1
OUT C
HALT
skip:
CMP B, 10
JNC big
LOAD C, 2
OUT C
HALT
big:
LOAD C, 3
OUT C
HALT
```

**Answer:**

For input 7 and 12, the output is: __________

**Explain your reasoning (show your work):**

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

---

## Section 3: Program Design (15 points)

### Question 6: Algorithm Design (7 points)

**Design an algorithm (in pseudocode or words) for a program that:**
- Reads 5 numbers from the user
- Calculates their sum
- Calculates their average
- Outputs both results

**Your algorithm:**

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

### Question 7: Code Optimization (8 points)

**This code is inefficient. Identify at least 3 problems and suggest improvements.**

```assembly
loop:
  LOAD A, 10      ; Load constant every iteration
  LOAD B, 5       ; Load constant every iteration
  ADD A, B        ; Calculate 10+5 every iteration
  LDM C, 100      ; Load from memory
  ADD C, A        ; Add result
  STM 100, C      ; Store back
  OUT C
  LDM D, 200      ; Counter
  ADD D, 1
  STM 200, D
  CMP D, 50
  JC loop
HALT
```

**Problem 1:** _____________________________________________________________

**Improvement:** ___________________________________________________________

**Problem 2:** _____________________________________________________________

**Improvement:** ___________________________________________________________

**Problem 3:** _____________________________________________________________

**Improvement:** ___________________________________________________________

---

# PART B: PRACTICAL PORTION (50 points)

**Write working assembly code for these challenges. Code must compile and run in BasCAT.**

## Challenge 1: Maximum Finder (25 points)

**Write an assembly program that:**
1. Reads exactly 5 numbers from the user (using IN)
2. Finds the maximum (largest) value
3. Outputs the maximum value
4. Must use a loop
5. Must use comparison (CMP)

**Requirements:**
- Must work for any 5 input values (0-255)
- Must use memory or stack to store values
- Must include comments
- Must end with HALT

**Write your code on the back of this page or on separate paper.**

**Grading Rubric:**
- Reads 5 inputs correctly: 5 pts
- Uses loop structure: 5 pts
- Correctly finds maximum: 10 pts
- Outputs result: 3 pts
- Code quality (comments, organization): 2 pts

---

## Challenge 2: Sum and Count (25 points)

**Write an assembly program that:**
1. Reads numbers from the user
2. Continues until user enters 0 (sentinel value)
3. Calculates how many numbers were entered (not counting the 0)
4. Calculates the sum of all numbers (not counting the 0)
5. Outputs the count, then outputs the sum

**Example:**
- User inputs: 5, 10, 15, 0
- Program outputs: 3 (count), then 30 (sum)

**Requirements:**
- Must handle 0 as sentinel (stop value)
- Must track count separately from sum
- Must include comments
- Must end with HALT

**Write your code on the back of this page or on separate paper.**

**Grading Rubric:**
- Loop with sentinel value (0): 7 pts
- Counts correctly: 6 pts
- Sums correctly: 7 pts
- Outputs both values: 3 pts
- Code quality (comments, organization): 2 pts

---

**END OF MIDTERM EXAM**

**Teacher:** Make sure students have access to:
- Assembly instruction reference sheet
- Scratch paper
- BasCAT (for practical portion)

---

# MIDTERM EXAM: COMPLETE ANSWER KEY

## PART A: WRITTEN PORTION ANSWERS

### Question 1: CPU Components (5 pts, 1 pt each)

**Correct Labels:**
1. **Register A, B, C, or D** (any register)
2. **Register A, B, C, or D** (any register)
3. **Control Unit** (manages execution)
4. **Program Counter (PC)** (tracks current instruction)
5. **Instruction Register (IR)** (holds current instruction)

**Grading Note:** Accept reasonable variations in diagram labeling. Focus on understanding, not exact placement.

### Question 2: Execution Trace (5 pts)

| After Instruction | Register A | Register B | Output |
|-------------------|------------|------------|--------|
| Initial state     | ?          | ?          | -      |
| LOAD A, 10        | **10**     | ?          | -      |
| LOAD B, 5         | 10         | **5**      | -      |
| ADD A, B          | **15**     | 5          | -      |
| SUB B, A          | 15         | **246**    | -      |
| OUT B             | 15         | 246        | **246**|

**Scoring:**
- 1 pt for each correct row
- Note: SUB B, A means B = B - A = 5 - 15 = -10 (wraps to 246 in unsigned 8-bit)

### Question 3: Multiple Choice (10 pts, 2 pts each)

1. **b) LDM** - Load from Memory
2. **b) LIFO** - Last In, First Out
3. **c) JNC** - Jump if No Carry (15 > 10, so Carry=0)
4. **a) Zero result**
5. **b) 00000000** - All bits AND to 0

### Question 4: Binary Logic (6 pts, 2 pts each)

1. **11111111** - OR combines all 1s
2. **00000000** - XOR of same value is always 0
3. **00110011** - NOT flips all bits

### Question 5: Control Flow Analysis (9 pts)

**Correct Answer: 3**

**Explanation (full credit):**
1. A = 7, B = 12
2. CMP A, 10: 7 < 10, so Carry flag = 1
3. JNC skip: Does NOT jump (Carry = 1)
4. LOAD C, 1; OUT C (outputs 1)
5. HALT

**Wait, let me trace again:**
- Actually, student might get confused. Let me retrace:
- A = 7, CMP A, 10 means A < 10, Carry = 1
- JNC skip means "jump if NO carry", so it does NOT jump
- Loads 1, outputs 1, halts

**Correction - Answer should be: 1**

**Scoring:**
- 6 pts: Correct output (1)
- 3 pts: Explanation shows understanding of flow
- Partial: 4 pts for output with weak explanation
- Partial: 2 pts for wrong output but shows some logic

### Question 6: Algorithm Design (7 pts)

**Good algorithm:**
```
1. Initialize sum to 0
2. For count from 1 to 5:
   a. Read number
   b. Add to sum
3. Calculate average = sum / 5
4. Output sum
5. Output average
```

**Scoring:**
- 7 pts: Complete algorithm that would work
- 5-6 pts: Missing one element
- 3-4 pts: Basic idea but incomplete
- 1-2 pts: Shows some understanding
- 0 pts: No meaningful attempt

### Question 7: Code Optimization (8 pts)

**Problems and Solutions:**

**Problem 1:** Loading constants (10, 5) inside loop
**Improvement:** Move `LOAD A, 10` and `LOAD B, 5` before loop, calculate sum before loop

**Problem 2:** Calculating 10+5 every iteration
**Improvement:** Calculate once before loop: `LOAD A, 15`

**Problem 3:** Loading counter from memory each iteration
**Improvement:** Keep counter in register D, only store to memory if needed at end

**Alternate Problem:** Multiple memory accesses per iteration
**Alternate Improvement:** Use registers when possible, minimize STM/LDM

**Scoring:**
- 2-3 pts per problem/solution pair
- Must identify real inefficiency
- Solution must actually improve performance
- Accept creative answers that make sense

---

## PART B: PRACTICAL PORTION ANSWERS

### Challenge 1: Maximum Finder (25 pts)

**Sample Solution:**

```assembly
; ==========================================
; Find maximum of 5 numbers
; ==========================================

; Read all 5 numbers and store in memory
LOAD D, 0           ; Counter
LOAD B, 10          ; Memory base address

read_loop:
  IN A              ; Read number
  STM B, A          ; Store at address B
  ADD B, 1          ; Next address
  ADD D, 1          ; Increment counter
  CMP D, 5
  JC read_loop      ; Loop if D < 5

; Find maximum
LOAD B, 10          ; Reset to start
LDM A, B            ; A = first number (max so far)
ADD B, 1            ; Move to second number
LOAD D, 1           ; Counter (already checked first)

find_max:
  LDM C, B          ; Load current number
  CMP C, A          ; Compare with max
  JNC not_bigger    ; If C <= A, skip
  MOV A, C          ; New max
not_bigger:
  ADD B, 1          ; Next address
  ADD D, 1          ; Increment counter
  CMP D, 5
  JC find_max       ; Loop if D < 5

; Output maximum
OUT A
HALT

; Memory map:
; 10-14: The 5 input numbers
; A: Current maximum
; B: Memory address pointer
; C: Current number being checked
; D: Loop counter
```

**Grading:**
- Reads 5 inputs (5 pts): Full credit if all 5 read and stored
- Uses loop (5 pts): Must have loop structure for reading OR finding
- Finds maximum (10 pts): Logic correctly identifies largest value
  - 10 pts: Perfect logic
  - 7-8 pts: Works but inefficient
  - 4-6 pts: Partial logic correct
  - 1-3 pts: Shows understanding of comparison
- Outputs result (3 pts): Outputs the maximum value
- Code quality (2 pts): Comments, organization, readability

### Challenge 2: Sum and Count (25 pts)

**Sample Solution:**

```assembly
; ==========================================
; Read numbers until 0, output count and sum
; ==========================================

LOAD B, 0           ; Sum accumulator
LOAD C, 0           ; Count accumulator

input_loop:
  IN A              ; Read number
  CMP A, 0          ; Check if sentinel (0)
  JZ done           ; If 0, we're done
  
  ADD B, A          ; Add to sum
  ADD C, 1          ; Increment count
  JMP input_loop    ; Continue

done:
  OUT C             ; Output count
  OUT B             ; Output sum
  HALT

; Registers:
; A: Current input
; B: Running sum
; C: Count of numbers
```

**Grading:**
- Sentinel loop (7 pts): Loop that stops at 0
  - 7 pts: Perfect sentinel handling
  - 5 pts: Loop works but minor issue
  - 3 pts: Basic loop structure
  - 1 pt: Shows understanding of concept
- Counts correctly (6 pts): Increments count for each non-zero
- Sums correctly (7 pts): Accumulates sum properly
- Outputs both (3 pts): Both count and sum output
- Code quality (2 pts): Comments, organization

---

# Teacher Notes for Grading

**Time Management:**
- Written section: 40-45 minutes
- Practical section: 45-50 minutes
- Allow students to use BasCAT for practical portion

**Common Mistakes:**
- Forgetting HALT
- Off-by-one errors in loops
- Wrong jump conditions
- Stack imbalance
- Not handling sentinel value properly

**Partial Credit:**
- Always give credit for correct logic even with syntax errors
- Code that almost works deserves substantial credit
- Reward proper structure and comments

**Red Flags:**
- Student can't write any loop
- Doesn't understand CMP/jumps
- Can't trace simple code
- No comments at all

**If Many Students Struggle:**
- Review loops and conditionals before continuing
- More practice with tracing code
- Additional scaffolding for projects

---

*End of Complete Midterm Exam with Answer Key*
