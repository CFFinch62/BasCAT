# Week 1 Quiz: Data Movement & Registers

**Name**: _________________________ **Date**: _______________ **Period**: _____

**Total Points**: 25

---

## Part 1: Multiple Choice (2 points each, 10 points total)

**Circle the correct answer.**

1. What does the LOAD instruction do?
   - a) Moves data between registers
   - b) Stores data in memory
   - **c) Puts an immediate value into a register**
   - d) Outputs data to screen

2. Which registers are available for general use in BasCAT?
   - a) PC and IR only
   - **b) A, B, C, and D**
   - c) Only register A
   - d) X, Y, and Z

3. What is the purpose of the MOV instruction?
   - a) Store value in memory
   - b) Load value from memory
   - **c) Copy value from one register to another**
   - d) Output data to screen

4. STM stands for:
   - **a) Store To Memory**
   - b) Set The Memory
   - c) Stop The Machine
   - d) Start Memory operation

5. After executing `LOAD A, 10`, what is in register A?
   - a) The address 10
   - **b) The value 10**
   - c) Whatever was at memory address 10
   - d) Nothing changes

---

## Part 2: Short Answer (3 points each, 9 points total)

**Write your answer in complete sentences.**

6. **What is the difference between LOAD and LDM?**

   ___________________________________________________________________________

   ___________________________________________________________________________

   ___________________________________________________________________________

7. **Why might you use MOV instead of LOAD?**

   ___________________________________________________________________________

   ___________________________________________________________________________

   ___________________________________________________________________________

8. **What does HALT do and why is it important?**

   ___________________________________________________________________________

   ___________________________________________________________________________

   ___________________________________________________________________________

---

## Part 3: Code Writing (6 points)

9. **Write assembly code to accomplish the following steps:**
   - Load the value 42 into register A
   - Copy the value from A to register B
   - Store B's value in memory address 100
   - Stop the program

**Write your code here:**

```assembly
_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________
```

---

**Grading:**
- Part 1: _____ / 10
- Part 2: _____ / 9
- Part 3: _____ / 6
- **TOTAL: _____ / 25**

**Teacher Comments:**

___________________________________________________________________________

___________________________________________________________________________
