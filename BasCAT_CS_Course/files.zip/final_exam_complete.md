# Final Exam: BasCAT Computer Architecture Course

**Name**: _________________________ **Date**: _______________

**Total Points**: 200 (100 written + 100 practical)
**Time**: 2 hours (120 minutes)

---

# PART A: WRITTEN PORTION (100 points)

## Section 1: Assembly Programming (25 points)

### Question 1: Code Writing (10 points)

**Write assembly code that reads 3 numbers and outputs them in reverse order.**

**Example:** Input: 5, 10, 15 → Output: 15, 10, 5

**Your code:**

```assembly
_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________
```

### Question 2: Debugging (8 points)

**Find and fix ALL 4 errors in this code:**

```assembly
; Calculate average of 2 numbers
INPUT A
INPUT B
ADD A, B
DIV A, 2
OUTPUT A
```

**Errors:**

1. _________________________________________________________________

2. _________________________________________________________________

3. _________________________________________________________________

4. _________________________________________________________________

### Question 3: Optimization (7 points)

**Optimize this code to use fewer instructions:**

```assembly
LOAD A, 5
ADD A, 5
ADD A, 5
ADD A, 5
OUT A
HALT
```

**Your optimized code:**

```assembly
_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________
```

---

## Section 2: BASIC Programming (25 points)

### Question 4: BASIC to Assembly (10 points)

**Convert this BASIC program to assembly:**

```basic
10 INPUT A
20 INPUT B
30 LET C = A + B
40 PRINT C
50 END
```

**Assembly version:**

```assembly
_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________
```

### Question 5: BASIC Code Writing (10 points)

**Write a BASIC program that:**
- Reads numbers until user enters -1
- Counts how many were positive (> 0)
- Counts how many were negative (< 0)
- Outputs both counts

**Your code:**

```basic
_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________

_________________________________________________
```

### Question 6: Array Operations (5 points)

**What does this code output?**

```basic
10 DIM A(3)
20 LET A(1) = 5
30 LET A(2) = 10
40 LET A(3) = 15
50 FOR I = 1 TO 3
60   PRINT A(I) * 2
70 NEXT I
80 END
```

**Output:** __________, __________, __________

---

## Section 3: Computer Architecture (25 points)

### Question 7: CPU Components (8 points)

**Match each component with its function:**

Components:
A. ALU
B. Control Unit
C. Registers
D. Program Counter

Functions:
1. ____ Performs arithmetic and logic operations
2. ____ Manages instruction execution sequence
3. ____ Fast storage for immediate data access
4. ____ Tracks current instruction address

### Question 8: Memory Hierarchy (8 points)

**Order these from FASTEST to SLOWEST (1 = fastest, 4 = slowest):**

____ Hard Disk Drive
____ CPU Registers
____ RAM (Main Memory)
____ Cache Memory

**Explain why this hierarchy exists (3-4 sentences):**

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

### Question 9: Instruction Encoding (9 points)

**Given this instruction format:**
```
[OPCODE - 4 bits][REG - 2 bits][VALUE - 8 bits]
```

**Encode this instruction in binary:**
`LOAD A, 42`

Assume: LOAD opcode = 0001, Register A = 00

**Binary encoding:** ________________________________

**Show your work:**

OPCODE: __________
REG: __________
VALUE: __________

---

## Section 4: Integration & Analysis (25 points)

### Question 10: Language Comparison (12 points)

**Complete this comparison table:**

| Aspect | Assembly | BASIC | Which is Better? |
|--------|----------|-------|------------------|
| Speed | | | |
| Ease of Writing | | | |
| Code Size | | | |
| Readability | | | |

**When would you choose assembly over BASIC? Give 2 specific scenarios:**

1. _____________________________________________________________________

2. _____________________________________________________________________

### Question 11: Compilation Process (8 points)

**Put these compilation stages in order (1-5):**

____ Assembly (machine code generation)
____ Lexical Analysis (tokenization)
____ Code Optimization
____ Parsing (syntax tree)
____ Code Generation (assembly output)

**Briefly describe what happens in the Parsing stage:**

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

### Question 12: System Design (5 points)

**You need to write a program for a smart thermostat with limited memory (256 bytes) that must respond quickly to temperature changes.**

**Which language would you choose and why?**

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

---

# PART B: PRACTICAL PORTION (100 points)

**Write working code in the specified language. Code must compile and run.**

## Challenge 1: Assembly - Data Analysis (50 points)

**Write an assembly program that:**

1. Reads exactly 10 numbers from the user
2. Calculates and outputs:
   - The sum of all numbers
   - The average (sum ÷ 10)
   - The minimum value
   - The maximum value
3. Must store all 10 numbers in memory
4. Must use loops
5. Must include comprehensive comments

**Requirements:**
- All 10 numbers stored: addresses 10-19
- Sum calculated correctly
- Average calculated (use repeated subtraction for division)
- Min and max found correctly
- Proper structure and comments
- Ends with HALT

**Write your complete program on separate paper or continue here:**

```assembly
; ==========================================
; PROGRAM: Data Analyzer
; AUTHOR: _____________________
; ==========================================

[Continue your code here...]
```

**Grading Rubric:**
- Reads and stores 10 numbers (10 pts)
- Calculates sum correctly (10 pts)
- Calculates average (10 pts)
- Finds minimum (7 pts)
- Finds maximum (7 pts)
- Code organization and comments (6 pts)

---

## Challenge 2: BASIC - Interactive Program (50 points)

**Write a BASIC program that implements a simple menu-driven calculator:**

**Features required:**
1. Display menu with options:
   - 1. Add two numbers
   - 2. Multiply two numbers
   - 3. Calculate factorial (using loop)
   - 4. Exit
2. Get user's choice
3. Perform selected operation
4. Display result
5. Return to menu (unless exit chosen)
6. Use GOSUB for each operation
7. Input validation (reject invalid menu choices)

**Requirements:**
- Menu system with loop
- At least 3 subroutines (one per operation)
- GOSUB/RETURN correctly used
- Input validation
- Clear prompts and output
- Proper END statement

**Write your complete program on separate paper or continue here:**

```basic
100 REM ===================================
110 REM  CALCULATOR PROGRAM
120 REM  AUTHOR: _____________________
130 REM ===================================

[Continue your code here...]
```

**Grading Rubric:**
- Menu display and loop (10 pts)
- Addition operation (8 pts)
- Multiplication operation (8 pts)
- Factorial operation (12 pts)
- Input validation (7 pts)
- GOSUB/RETURN structure (5 pts)

---

**END OF FINAL EXAM**

---

# FINAL EXAM: COMPLETE ANSWER KEY

## PART A: WRITTEN PORTION ANSWERS

### Section 1: Assembly Programming

**Question 1: Reverse Order (10 pts)**

**Sample Solution:**
```assembly
IN A
IN B
IN C
PUSH A
PUSH B
PUSH C
POP A      ; Gets C
OUT A
POP A      ; Gets B
OUT A
POP A      ; Gets A (first input)
OUT A
HALT
```

**Alternate Solution:**
```assembly
IN A
STM 10, A
IN B
STM 11, B
IN C
OUT C
OUT B
LDM A, 10
OUT A
HALT
```

**Scoring:**
- 10 pts: Correct logic, outputs in reverse
- 8 pts: Mostly correct, minor error
- 6 pts: Right idea but significant error
- 3-4 pts: Shows understanding of stack or memory
- 0-2 pts: Minimal attempt

**Question 2: Debugging (8 pts, 2 pts each)**

**Errors:**
1. `INPUT` should be `IN` (not a BasCAT instruction)
2. `INPUT B` should be `IN B`
3. `DIV A, 2` - BasCAT doesn't have DIV instruction (need repeated subtraction or note it's not possible)
4. `OUTPUT` should be `OUT`
5. Missing `HALT`

**Scoring:** 2 pts for each error correctly identified and fixed

**Question 3: Optimization (7 pts)**

**Optimized code:**
```assembly
LOAD A, 5
ADD A, A      ; A = 10
ADD A, A      ; A = 20
OUT A
HALT
```

OR:
```assembly
LOAD A, 20    ; Pre-calculate 5+5+5+5
OUT A
HALT
```

**Scoring:**
- 7 pts: Significantly fewer instructions (2-3 vs 6)
- 5 pts: Some optimization
- 3 pts: Attempted optimization
- 0 pts: No improvement

---

### Section 2: BASIC Programming

**Question 4: BASIC to Assembly (10 pts)**

**Correct conversion:**
```assembly
IN A
IN B
ADD A, B
OUT A
HALT
```

**Scoring:**
- 10 pts: Correct conversion
- 8 pts: Minor syntax error
- 6 pts: Logic correct but multiple errors
- 3 pts: Shows understanding of basics
- 0 pts: No meaningful attempt

**Question 5: Count Positive/Negative (10 pts)**

**Sample Solution:**
```basic
10 REM Count positive and negative
20 LET POS = 0
30 LET NEG = 0
40 INPUT N
50 IF N = -1 THEN GOTO 100
60 IF N > 0 THEN LET POS = POS + 1
70 IF N < 0 THEN LET NEG = NEG + 1
80 GOTO 40
100 PRINT "Positive: "; POS
110 PRINT "Negative: "; NEG
120 END
```

**Scoring:**
- 10 pts: Complete, correct solution
- 8 pts: Works with minor issues
- 6 pts: Logic mostly correct
- 4 pts: Shows understanding of concept
- 0-2 pts: Minimal attempt

**Question 6: Array Output (5 pts)**

**Answer: 10, 20, 30**

**Scoring:** 5 pts for all correct, 3 pts for 2/3 correct, 0 pts otherwise

---

### Section 3: Computer Architecture

**Question 7: CPU Components (8 pts, 2 pts each)**

1. **A** - ALU performs arithmetic/logic
2. **B** - Control Unit manages execution
3. **C** - Registers provide fast storage
4. **D** - Program Counter tracks instruction address

**Question 8: Memory Hierarchy (8 pts)**

**Correct order:**
1. CPU Registers (fastest)
2. Cache Memory
3. RAM (Main Memory)
4. Hard Disk Drive (slowest)

**Explanation (5 pts):**
Good answer includes:
- Faster memory is more expensive
- Trade-off between speed, cost, and capacity
- Hierarchy balances performance and cost
- Frequently used data kept in faster memory

**Question 9: Instruction Encoding (9 pts)**

**Binary encoding:** `0001 00 00101010`

**Work shown:**
- OPCODE: 0001 (3 pts)
- REG: 00 (Register A) (3 pts)
- VALUE: 00101010 (42 in binary) (3 pts)

---

### Section 4: Integration & Analysis

**Question 10: Language Comparison (12 pts)**

| Aspect | Assembly | BASIC | Which is Better? |
|--------|----------|-------|------------------|
| Speed | Fast | Slower | Assembly |
| Ease of Writing | Hard | Easy | BASIC |
| Code Size | Larger | Smaller | BASIC |
| Readability | Poor | Good | BASIC |

**Scenarios for Assembly (4 pts, 2 each):**
1. Device drivers (need hardware control)
2. Real-time systems (speed critical)
3. Embedded systems (limited resources)
4. Performance-critical code sections

**Question 11: Compilation Process (8 pts)**

**Correct order:**
1. Lexical Analysis
2. Parsing
3. Code Generation
4. Code Optimization
5. Assembly

**Parsing explanation (3 pts):**
Creates syntax tree from tokens, checks grammar rules, builds structure for code generation

**Question 12: System Design (5 pts)**

**Good answer:**
"I would choose assembly because:
- Limited memory (256 bytes) requires efficient code
- Real-time temperature response needs speed
- Direct hardware control may be needed
- Assembly produces smallest, fastest code"

**Scoring:** 5 pts for justified assembly choice with multiple reasons

---

## PART B: PRACTICAL PORTION ANSWERS

### Challenge 1: Data Analysis (50 pts)

**Sample Solution:**

```assembly
; ==========================================
; DATA ANALYZER
; Reads 10 numbers, calculates statistics
; ==========================================

; === READ NUMBERS ===
LOAD B, 10          ; Memory base address
LOAD D, 0           ; Counter

read_loop:
  IN A
  STM B, A          ; Store at address B
  ADD B, 1          ; Next address
  ADD D, 1          ; Increment counter
  CMP D, 10
  JC read_loop      ; Continue if D < 10

; === CALCULATE SUM ===
LOAD B, 10          ; Reset to start
LOAD C, 0           ; Sum accumulator
LOAD D, 0           ; Counter

sum_loop:
  LDM A, B
  ADD C, A          ; Add to sum
  ADD B, 1
  ADD D, 1
  CMP D, 10
  JC sum_loop

OUT C               ; Output sum

; === CALCULATE AVERAGE ===
; Average = sum / 10
; Using repeated subtraction
MOV A, C            ; A = sum
LOAD B, 0           ; Count subtractions

avg_loop:
  CMP A, 10
  JC avg_done       ; If A < 10, done
  SUB A, 10
  ADD B, 1
  JMP avg_loop
  
avg_done:
OUT B               ; Output average

; === FIND MINIMUM ===
LOAD B, 10          ; Reset pointer
LDM A, B            ; A = first number (min so far)
ADD B, 1
LOAD D, 1           ; Counter

min_loop:
  LDM C, B
  CMP C, A
  JNC not_smaller   ; If C >= A, skip
  MOV A, C          ; New min
not_smaller:
  ADD B, 1
  ADD D, 1
  CMP D, 10
  JC min_loop

OUT A               ; Output minimum

; === FIND MAXIMUM ===
LOAD B, 10          ; Reset pointer
LDM A, B            ; A = first number (max so far)
ADD B, 1
LOAD D, 1

max_loop:
  LDM C, B
  CMP C, A
  JC not_bigger     ; If C < A, skip
  MOV A, C          ; New max
not_bigger:
  ADD B, 1
  ADD D, 1
  CMP D, 10
  JC max_loop

OUT A               ; Output maximum
HALT

; === MEMORY MAP ===
; 10-19: The 10 input numbers
; A: Working register
; B: Memory pointer
; C: Accumulator/temp
; D: Counter
```

**Grading:**
- Reads/stores 10 numbers (10 pts)
- Calculates sum (10 pts)
- Calculates average (10 pts)
- Finds minimum (7 pts)
- Finds maximum (7 pts)
- Organization/comments (6 pts)

### Challenge 2: BASIC Calculator (50 pts)

**Sample Solution:**

```basic
100 REM ===================================
110 REM  MENU-DRIVEN CALCULATOR
120 REM ===================================
130
200 REM Main menu loop
210 PRINT "===== CALCULATOR ====="
220 PRINT "1. Add"
230 PRINT "2. Multiply"
240 PRINT "3. Factorial"
250 PRINT "4. Exit"
260 PRINT "======================"
270 INPUT "Choice (1-4): "; C
280
290 REM Validate input
300 IF C < 1 OR C > 4 THEN GOTO 1000
310
320 IF C = 1 THEN GOSUB 2000
330 IF C = 2 THEN GOSUB 3000
340 IF C = 3 THEN GOSUB 4000
350 IF C = 4 THEN END
360 GOTO 200
370
1000 REM Invalid input
1010 PRINT "Invalid choice! Try again."
1020 GOTO 200
1030
2000 REM Addition subroutine
2010 INPUT "First number: "; A
2020 INPUT "Second number: "; B
2030 LET R = A + B
2040 PRINT "Result: "; R
2050 RETURN
2060
3000 REM Multiplication subroutine
3010 INPUT "First number: "; A
3020 INPUT "Second number: "; B
3030 LET R = A * B
3040 PRINT "Result: "; R
3050 RETURN
3060
4000 REM Factorial subroutine
4010 INPUT "Number (1-10): "; N
4020 IF N < 1 OR N > 10 THEN PRINT "Out of range!": RETURN
4030 LET F = 1
4040 FOR I = 1 TO N
4050   LET F = F * I
4060 NEXT I
4070 PRINT N; "! = "; F
4080 RETURN
4090
9999 END
```

**Grading:**
- Menu display/loop (10 pts)
- Addition (8 pts)
- Multiplication (8 pts)
- Factorial (12 pts)
- Input validation (7 pts)
- GOSUB/RETURN (5 pts)

---

# Teacher Grading Notes

**Time Management:**
- Part A: 60 minutes
- Part B: 60 minutes
- Allow breaks

**Scoring Philosophy:**
- Reward understanding over syntax
- Partial credit generously
- Focus on concepts mastered

**Common Issues:**
- Forgetting HALT in assembly
- Off-by-one in loops
- Division attempts (not in instruction set)
- Stack/memory management

**If Class Struggles:**
- This indicates gaps in earlier material
- Consider remediation
- Review before next semester

**Pass/Fail Threshold:**
- 120/200 (60%) minimum for passing
- 160/200 (80%) shows strong mastery
- 180+ (90%) exceptional understanding

---

*End of Complete Final Exam with Answer Key*
