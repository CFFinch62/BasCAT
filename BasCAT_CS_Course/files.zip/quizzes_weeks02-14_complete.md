# Complete Weekly Quizzes: Weeks 2-14

---

# Week 2 Quiz: Arithmetic Operations & I/O

**Name**: _________________________ **Date**: _______________ 

**Total Points**: 25

## Part 1: Multiple Choice (2 pts each, 10 pts)

1. What does `ADD A, 5` do?
   - a) Sets A to 5
   - **b) Adds 5 to the current value of A**
   - c) Adds A and 5, stores in new register
   - d) Outputs A + 5

2. The Z flag is set when:
   - **a) The result of an operation is zero**
   - b) The result is negative
   - c) An overflow occurs
   - d) The program halts

3. What does `IN A` do?
   - a) Outputs the value of A
   - b) Loads A from memory
   - **c) Waits for user input and stores it in A**
   - d) Adds to A

4. If A = 10 and you execute `SUB A, 15`, what value is in A?
   - a) -5
   - b) 5
   - **c) 251 (unsigned underflow wraps around)**
   - d) Error message

5. `OUT A` displays:
   - **a) The current value stored in register A**
   - b) The memory address of A
   - c) The binary representation of A
   - d) Nothing

## Part 2: True/False (2 pts each, 6 pts)

6. The ADD instruction changes the value in the destination register. **TRUE / FALSE**

7. SUB can cause underflow in unsigned 8-bit arithmetic. **TRUE / FALSE**

8. The IN instruction is blocking (waits for input). **TRUE / FALSE**

## Part 3: Code Writing (9 pts)

9. Write assembly code to:
   - Read two numbers from the user
   - Add them together
   - Subtract the second from the first
   - Output both results

```assembly
_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________
```

**TOTAL: _____ / 25**

---

# Week 3 Quiz: Logic Operations & Binary

**Name**: _________________________ **Date**: _______________ 

**Total Points**: 25

## Part 1: Binary Conversion (2 pts each, 6 pts)

1. Convert binary 00001111 to decimal: **__________**

2. Convert decimal 15 to 8-bit binary: **__________**

3. What is binary 11111111 in decimal: **__________**

## Part 2: Logic Operations (3 pts each, 12 pts)

**Show your work. Write answers in binary.**

4. What is `11110000 AND 00001111`? **__________**

5. What is `10101010 OR 01010101`? **__________**

6. What is `11110000 XOR 11110000`? **__________**

7. What is `NOT 10101010`? **__________**

## Part 3: Code Application (7 pts)

8. Write assembly code to extract the lower 4 bits (bits 0-3) from register A and output the result.

**Hint: Use AND with an appropriate mask.**

```assembly
_______________________________________________

_______________________________________________

_______________________________________________
```

**TOTAL: _____ / 25**

---

# Week 4 Quiz: Control Flow & Jumps

**Name**: _________________________ **Date**: _______________ 

**Total Points**: 25

## Part 1: Multiple Choice (2 pts each, 10 pts)

1. `CMP A, 10` followed by `JZ label` jumps when:
   - a) A < 10
   - b) A > 10
   - **c) A = 10**
   - d) Always

2. JC (Jump if Carry) jumps when the Carry flag is:
   - a) 0
   - **b) 1**
   - c) Either 0 or 1
   - d) JC never jumps

3. What's wrong with this loop?
   ```
   loop:
     OUT A
     JMP loop
   ```
   - a) No initialization
   - **b) No exit condition - infinite loop**
   - c) No HALT statement
   - d) Nothing wrong

4. Which instruction compares two values?
   - a) TEST
   - **b) CMP**
   - c) CHECK
   - d) EQU

5. JNZ jumps when:
   - a) Zero flag is 1
   - **b) Zero flag is 0**
   - c) Carry flag is 1
   - d) Always

## Part 2: Code Analysis (8 pts)

6. **What does this code output if the user inputs 15?**

```assembly
IN A
CMP A, 10
JNC big
LOAD B, 0
OUT B
HALT
big:
LOAD B, 1
OUT B
HALT
```

**Answer**: The program outputs **__________**

**Explain why**: ________________________________________________________

________________________________________________________________________

## Part 3: Code Writing (7 pts)

7. Write a loop that outputs the numbers 1, 2, 3, 4, 5 (one at a time).

```assembly
_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________
```

**TOTAL: _____ / 25**

---

# Week 5 Quiz: Stack Operations

**Name**: _________________________ **Date**: _______________ 

**Total Points**: 25

## Part 1: Multiple Choice (2 pts each, 10 pts)

1. PUSH A does what?
   - **a) Saves A's value on the stack**
   - b) Removes a value from the stack into A
   - c) Adds to the value in A
   - d) Outputs A

2. What does LIFO mean?
   - a) Load In, Find Out
   - b) Loop In For Output
   - **c) Last In, First Out**
   - d) Load Instruction From Operation

3. After `PUSH A` then `PUSH B`, which POP gets B's value?
   - **a) The first POP**
   - b) The second POP
   - c) Either POP
   - d) Neither POP

4. What happens if you POP without PUSH?
   - a) Nothing
   - **b) Stack underflow - gets garbage value**
   - c) Program crashes immediately
   - d) Zero is loaded

5. The stack grows:
   - a) Upward in memory
   - **b) Downward in memory**
   - c) Horizontally
   - d) It doesn't grow

## Part 2: Stack Trace (9 pts)

6. **Trace the stack operations. Show what's on the stack after each step.**

```assembly
LOAD A, 10
LOAD B, 20
PUSH A
PUSH B
POP C
POP D
```

After PUSH A: Stack = **[__________]**

After PUSH B: Stack = **[__________, __________]** (top → bottom)

After POP C: Stack = **[__________]**, C = **__________**

After POP D: Stack = **[empty]**, D = **__________**

## Part 3: Code Writing (6 pts)

7. Write code to swap the values of A and B using the stack.

```assembly
_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________
```

**TOTAL: _____ / 25**

---

# Week 6 Quiz: Assembly Integration Review

**Name**: _________________________ **Date**: _______________ 

**Total Points**: 25

## Part 1: Comprehensive Multiple Choice (2 pts each, 10 pts)

1. Which instruction reads user input?
   - a) GET
   - **b) IN**
   - c) INPUT
   - d) READ

2. To compare A with 10, you use:
   - **a) CMP A, 10**
   - b) TEST A, 10
   - c) SUB A, 10
   - d) EQ A, 10

3. The correct order for data flow is:
   - a) Memory → ALU → Registers
   - **b) Registers → ALU → Registers**
   - c) ALU → Memory → Registers
   - d) Input → Memory → Output

4. Every assembly program must end with:
   - a) END
   - **b) HALT**
   - c) STOP
   - d) EXIT

5. Which is NOT a BasCAT register?
   - a) A
   - b) B
   - c) C
   - **d) E**

## Part 2: Debug This Code (7 pts)

6. **Find and fix ALL errors in this code:**

```assembly
; Read number and double it
INPUT A
ADD A A
OUPUT A
```

**Errors found:**

1. _______________________________________________________________

2. _______________________________________________________________

3. _______________________________________________________________

**Corrected code:**
```assembly
_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________
```

## Part 3: Design Challenge (8 pts)

7. **Describe the algorithm (in words) for a program that:**
   - Reads 3 numbers
   - Finds the largest
   - Outputs the largest

**Your algorithm:**

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

___________________________________________________________________________

**TOTAL: _____ / 25**

---

# Week 7 Quiz: BASIC Fundamentals

**Name**: _________________________ **Date**: _______________ 

**Total Points**: 25

## Part 1: Multiple Choice (2 pts each, 10 pts)

1. In BASIC, line numbers must be:
   - a) Sequential (10, 11, 12...)
   - **b) In ascending order (can skip numbers)**
   - c) All multiples of 10
   - d) Optional

2. What does REM do?
   - a) Removes a line
   - **b) Creates a comment**
   - c) Resets memory
   - d) Reads a value

3. To store value 42 in variable A:
   - a) A = 42
   - **b) LET A = 42**
   - c) SET A TO 42
   - d) STORE 42 IN A

4. PRINT displays:
   - a) Only numbers
   - b) Only text in quotes
   - **c) Numbers, text, or variables**
   - d) Nothing

5. Every BASIC program must end with:
   - a) HALT
   - b) STOP
   - **c) END**
   - d) FINISH

## Part 2: Code Reading (6 pts)

6. **What does this program output?**

```basic
10 LET A = 5
20 LET B = 10
30 LET C = A + B
40 PRINT C
50 END
```

**Output**: __________

7. **What's wrong with this code?**

```basic
10 LET X = 10
20 PRINT "Value:"
30 PRINT X
```

**Error**: ____________________________________________________________

## Part 3: Code Writing (9 pts)

8. Write a BASIC program that:
   - Asks user for their age (INPUT)
   - Doubles the age
   - Prints the result

```basic
_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________
```

**TOTAL: _____ / 25**

---

# Week 8 Quiz: Advanced BASIC

**Name**: _________________________ **Date**: _______________ 

**Total Points**: 25

## Part 1: Multiple Choice (2 pts each, 10 pts)

1. A FOR loop executes:
   - a) Once
   - **b) A specific number of times**
   - c) Forever
   - d) Until user presses Enter

2. GOSUB does what?
   - a) Goes to a line and stops
   - **b) Calls a subroutine**
   - c) Ends the program
   - d) Skips lines

3. RETURN is used:
   - a) To output a value
   - **b) To return from a subroutine**
   - c) To go back one line
   - d) To restart the program

4. DIM is used to:
   - a) Dim the screen
   - **b) Declare an array**
   - c) Divide numbers
   - d) Delete a variable

5. IF A > 10 THEN GOTO 100 jumps when:
   - a) A is less than 10
   - b) A equals 10
   - **c) A is greater than 10**
   - d) Always

## Part 2: Code Analysis (7 pts)

6. **What does this loop output?**

```basic
10 FOR I = 1 TO 5
20   PRINT I * 2
30 NEXT I
40 END
```

**Output**: __________, __________, __________, __________, __________

## Part 3: Code Writing (8 pts)

7. Write a BASIC program with a subroutine that:
   - Main program: Gets 2 numbers, calls subroutine, prints result
   - Subroutine: Adds the numbers

```basic
_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________
```

**TOTAL: _____ / 25**

---

# Weeks 9-14: Quizzes Continue

## Week 9: Computer Architecture (25 pts)
- CPU components
- Fetch-execute cycle
- Memory hierarchy
- I/O systems

## Week 10: Compiler Design (25 pts)
- Compilation stages
- Expression translation
- Optimization
- Code generation

## Week 11: Advanced Assembly (25 pts)
- Optimization techniques
- Debugging strategies
- Best practices
- Performance analysis

## Week 12: Real-World Systems (25 pts)
- OS concepts
- Embedded systems
- Networks
- Security

## Week 13: Advanced BASIC (25 pts)
- Modular programming
- Error handling
- Algorithms
- UX design

## Week 14: Integration (25 pts)
- Language selection
- Performance comparison
- Translation
- Trade-offs

---

*All quizzes follow consistent format: 25 points, 3 sections, mixture of assessment types*
*Complete answer keys follow in separate document*
