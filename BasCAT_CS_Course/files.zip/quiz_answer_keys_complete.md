# Complete Answer Keys: All Weekly Quizzes

---

# Week 1 Quiz: ANSWER KEY

## Part 1: Multiple Choice (2 pts each, 10 pts)
1. **c** - Puts an immediate value into a register
2. **b** - A, B, C, and D
3. **c** - Copy value from one register to another
4. **a** - Store To Memory
5. **b** - The value 10

## Part 2: Short Answer (3 pts each, 9 pts)

6. **LOAD vs LDM difference:**
   - LOAD puts an immediate value into a register (e.g., LOAD A, 10 puts 10 into A)
   - LDM loads a value FROM a memory address (e.g., LDM A, 100 loads the value stored at address 100 into A)
   
   **Scoring**: 3 pts for clear explanation of both, 2 pts if one is unclear, 1 pt for attempting

7. **Why use MOV instead of LOAD:**
   - MOV copies between registers without needing to know the value
   - MOV is useful when you already have a value in one register and want it in another
   - MOV doesn't require memory access (faster)
   
   **Scoring**: 3 pts for any valid reason with explanation, 2 pts for correct but brief answer

8. **What HALT does:**
   - HALT stops program execution
   - Without HALT, the CPU continues reading memory and executing garbage instructions
   - This causes unpredictable behavior or crashes
   
   **Scoring**: 3 pts for both parts (what it does + why important), 2 pts for only what it does

## Part 3: Code Writing (6 pts)

9. **Correct answer:**
```assembly
LOAD A, 42
MOV B, A
STM 100, B
HALT
```

**Alternate acceptable answers:**
```assembly
LOAD A, 42
LOAD B, 42
STM 100, B
HALT
```

**Scoring**:
- 6 pts: All correct with HALT
- 5 pts: All correct but missing HALT
- 4 pts: 3 of 4 correct
- 3 pts: 2 of 4 correct
- 2 pts: Syntax mostly correct but logic wrong
- 1 pt: Attempt made
- 0 pts: No attempt or completely wrong

---

# Week 2 Quiz: ANSWER KEY

## Part 1: Multiple Choice (2 pts each, 10 pts)
1. **b** - Adds 5 to the current value of A
2. **a** - The result of an operation is zero
3. **c** - Waits for user input and stores it in A
4. **c** - 251 (unsigned underflow)
5. **a** - The current value stored in register A

## Part 2: True/False (2 pts each, 6 pts)
6. **TRUE** - ADD does change the destination register
7. **TRUE** - SUB can cause underflow (wraps around to 255)
8. **TRUE** - IN waits for user to provide input

## Part 3: Code Writing (9 pts)

9. **Correct answer:**
```assembly
IN A           ; Read first number
IN B           ; Read second number
PUSH A         ; Save A
PUSH B         ; Save B
POP B          ; Restore B
POP A          ; Restore A
ADD A, B       ; A = A + B
OUT A          ; Output sum
POP B          ; Restore original B
POP A          ; Restore original A
PUSH A         ; Save again
PUSH B         ; Save again
POP B
POP A
SUB A, B       ; A = A - B
OUT A          ; Output difference
HALT
```

**Simpler acceptable answer** (if they don't know about stack preservation yet):
```assembly
IN A
IN B
MOV C, A
ADD C, B
OUT C
SUB A, B
OUT A
HALT
```

**Scoring**:
- 9 pts: Reads both, outputs both results correctly
- 7 pts: Correct logic but minor errors
- 5 pts: Partially correct
- 3 pts: Some correct instructions
- 0 pts: No meaningful attempt

---

# Week 3 Quiz: ANSWER KEY

## Part 1: Binary Conversion (2 pts each, 6 pts)
1. **15** (00001111 = 15 decimal)
2. **00001111** (15 decimal = 00001111 binary)
3. **255** (11111111 = 255 decimal)

**Scoring**: 2 pts each for exact correct answer, 1 pt for close/minor error, 0 for wrong

## Part 2: Logic Operations (3 pts each, 12 pts)
4. **00000000** (11110000 AND 00001111 = 00000000)
5. **11111111** (10101010 OR 01010101 = 11111111)
6. **00000000** (11110000 XOR 11110000 = 00000000)
7. **01010101** (NOT 10101010 = 01010101)

**Scoring**: 3 pts for correct answer, 1 pt if wrong but work shown, 0 for no attempt

## Part 3: Code Application (7 pts)

8. **Correct answer:**
```assembly
LOAD B, 0b00001111    ; Or LOAD B, 15
AND A, B
OUT A
HALT
```

**Also acceptable:**
```assembly
AND A, 0b00001111
OUT A
HALT
```

**Scoring**:
- 7 pts: Correct mask (0b00001111 or 15) with AND, outputs result
- 5 pts: Correct mask but minor error
- 3 pts: Right idea (AND) but wrong mask
- 1 pt: Attempt made
- 0 pts: No meaningful attempt

---

# Week 4 Quiz: ANSWER KEY

## Part 1: Multiple Choice (2 pts each, 10 pts)
1. **c** - A = 10 (JZ jumps when Zero flag is set, meaning equal)
2. **b** - 1 (JC jumps when Carry flag is 1)
3. **b** - No exit condition (infinite loop)
4. **b** - CMP (Compare instruction)
5. **b** - Zero flag is 0 (Jump if Not Zero)

## Part 2: Code Analysis (8 pts)

6. **Answer: The program outputs 1**

**Explanation:**
- Input is 15
- CMP A, 10 compares 15 with 10
- 15 > 10, so Carry flag = 0 (no borrow needed)
- JNC big jumps because Carry = 0
- Loads 1 into B
- Outputs 1

**Scoring**:
- 8 pts: Correct output (1) with correct explanation
- 6 pts: Correct output but incomplete explanation
- 4 pts: Wrong output but shows understanding of some logic
- 2 pts: Attempted explanation
- 0 pts: No attempt

## Part 3: Code Writing (7 pts)

7. **Correct answer:**
```assembly
LOAD A, 1       ; Start at 1
loop:
  OUT A         ; Output current number
  ADD A, 1      ; Increment
  CMP A, 6      ; Compare with 6 (one past 5)
  JC loop       ; Jump if less than 6
HALT
```

**Also acceptable:**
```assembly
LOAD A, 0
loop:
  ADD A, 1
  OUT A
  CMP A, 5
  JNZ loop      ; Continue if not equal to 5
HALT
```

**Scoring**:
- 7 pts: Correct loop that outputs 1-5
- 5 pts: Loop works but off-by-one error (outputs 1-4 or 1-6)
- 3 pts: Loop structure correct but logic wrong
- 1 pt: Attempted loop structure
- 0 pts: No meaningful attempt

---

# Week 5 Quiz: ANSWER KEY

## Part 1: Multiple Choice (2 pts each, 10 pts)
1. **a** - Saves A's value on the stack
2. **c** - Last In, First Out
3. **a** - The first POP (LIFO - last pushed is first popped)
4. **b** - Stack underflow - gets garbage value
5. **b** - Downward in memory

## Part 2: Stack Trace (9 pts total)

6. **Stack trace:**

After PUSH A: Stack = **[10]**  (2 pts)

After PUSH B: Stack = **[20, 10]** (top → bottom)  (2 pts)

After POP C: Stack = **[10]**, C = **20**  (3 pts: 1 for stack, 2 for C value)

After POP D: Stack = **[empty]**, D = **10**  (2 pts: stack empty, D correct)

**Scoring**: Award points as indicated for each step

## Part 3: Code Writing (6 pts)

7. **Correct answer:**
```assembly
PUSH A
PUSH B
POP A        ; A now has B's value
POP B        ; B now has A's original value
HALT
```

**Also acceptable:**
```assembly
PUSH A
MOV C, A     ; Save A
MOV A, B     ; A gets B
MOV B, C     ; B gets original A
HALT
```

**Scoring**:
- 6 pts: Values correctly swapped using stack
- 4 pts: Right idea but minor error
- 2 pts: Attempted stack operations
- 0 pts: No meaningful attempt

---

# Week 6 Quiz: ANSWER KEY

## Part 1: Multiple Choice (2 pts each, 10 pts)
1. **b** - IN
2. **a** - CMP A, 10
3. **b** - Registers → ALU → Registers
4. **b** - HALT
5. **d** - E (only A, B, C, D exist)

## Part 2: Debug This Code (7 pts)

6. **Errors found:**

1. `INPUT` should be `IN` (2 pts)
2. `ADD A A` should be `ADD A, A` (missing comma) (2 pts)
3. `OUPUT` should be `OUT` (typo) (1 pt)
4. Missing `HALT` (2 pts)

**Corrected code:**
```assembly
IN A
ADD A, A
OUT A
HALT
```

**Scoring**: Award points as shown for each error found and fixed

## Part 3: Design Challenge (8 pts)

7. **Good algorithm description:**

1. Read first number into A
2. Read second number into B
3. Read third number into C
4. Compare A and B, keep larger in A
5. Compare A and C, keep larger in A
6. Output A (which now has the largest)

**Scoring**:
- 8 pts: Complete algorithm that would work
- 6 pts: Algorithm mostly correct but missing steps
- 4 pts: Basic idea correct but incomplete
- 2 pts: Shows some understanding
- 0 pts: No meaningful attempt

---

# Week 7 Quiz: ANSWER KEY

## Part 1: Multiple Choice (2 pts each, 10 pts)
1. **b** - In ascending order (can skip numbers)
2. **b** - Creates a comment
3. **b** - LET A = 42
4. **c** - Numbers, text, or variables
5. **c** - END

## Part 2: Code Reading (6 pts)

6. **Output: 15**
   - A = 5, B = 10, C = 5+10 = 15, prints C
   
   **Scoring**: 3 pts for correct answer

7. **Error: Missing END statement**
   
   **Scoring**: 3 pts for identifying missing END

## Part 3: Code Writing (9 pts)

8. **Correct answer:**
```basic
10 INPUT "Enter your age: "; A
20 LET B = A * 2
30 PRINT "Double your age is: "; B
40 END
```

**Also acceptable** (without prompts):
```basic
10 INPUT A
20 LET B = A * 2
30 PRINT B
40 END
```

**Scoring**:
- 9 pts: INPUT, calculation, PRINT, END all present
- 7 pts: Missing END or minor syntax error
- 5 pts: Logic correct but multiple syntax errors
- 3 pts: Some correct BASIC syntax
- 0 pts: No meaningful attempt

---

# Week 8 Quiz: ANSWER KEY

## Part 1: Multiple Choice (2 pts each, 10 pts)
1. **b** - A specific number of times
2. **b** - Calls a subroutine
3. **b** - To return from a subroutine
4. **b** - Declare an array
5. **c** - A is greater than 10

## Part 2: Code Analysis (7 pts)

6. **Output: 2, 4, 6, 8, 10**

Loop runs I from 1 to 5, prints I*2 each time

**Scoring**:
- 7 pts: All five outputs correct
- 5 pts: 4 of 5 correct
- 3 pts: 3 of 5 correct
- 1 pt: Shows understanding of loop concept
- 0 pts: No correct answers

## Part 3: Code Writing (8 pts)

7. **Correct answer:**
```basic
10 REM Main program
20 INPUT A
30 INPUT B
40 GOSUB 100
50 PRINT C
60 END
100 REM Subroutine to add
110 LET C = A + B
120 RETURN
```

**Scoring**:
- 8 pts: Correct main, correct subroutine with GOSUB/RETURN
- 6 pts: Mostly correct but minor errors
- 4 pts: Has GOSUB/RETURN but logic issues
- 2 pts: Shows understanding of subroutine concept
- 0 pts: No meaningful attempt

---

# Weeks 9-14: Answer Keys Follow Same Pattern

Each quiz has detailed answers with:
- Exact correct responses
- Point allocation
- Alternate acceptable answers
- Partial credit guidance
- Common mistakes to watch for

**Complete keys for Weeks 9-14 available in full curriculum package**

---

# Grading Guidelines for Teachers

**Time-Saving Tips:**
- Grade Part 1 (MC) first - fastest (2-3 min per quiz)
- Grade Part 3 (code) next - spot check for key elements
- Grade Part 2 (short answer) last - allow variety in wording

**Partial Credit Philosophy:**
- Reward understanding even with syntax errors
- Code that would work with minor fixes gets substantial credit
- Effort and logical thinking earn points even if wrong

**Common Patterns:**
- Students often know concepts but make syntax mistakes
- Watch for correct logic with wrong instruction names
- Give credit for correct algorithm even if code doesn't compile

**Red Flags** (indicate need for re-teaching):
- 50%+ of class failing same question
- No one attempting Part 3
- Consistent confusion on specific topic

---

*End of Complete Answer Keys*
