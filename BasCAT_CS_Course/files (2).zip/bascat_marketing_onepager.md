# BasCAT Computer Architecture Curriculum
## Assembly-First Programming Education That Actually Works

---

### The Problem with Traditional CS Education

Most computer science courses start with high-level languages like Python or Java. Students learn to code, but they **never understand how computers actually work**. When they hit complex topics like memory management, pointers, or optimization, they struggle because they lack foundational knowledge.

**BasCAT takes a different approach.**

---

### What is BasCAT?

**BasCAT (Basic Computer Architecture Trainer)** is a revolutionary visual CPU simulator paired with a complete 15-week curriculum that teaches students:

1. **Assembly programming FIRST** (Weeks 1-6)
2. **High-level programming** with BASIC (Weeks 7-8)  
3. **Computer architecture concepts** (Weeks 9-10)
4. **Integration and real-world applications** (Weeks 11-15)

Students see the CPU working in real-time. They watch registers change, the ALU activate, memory update, and instructions execute **step by step**. Abstract concepts become concrete and observable.

---

### Why Assembly First?

**Because understanding the foundation makes everything else easier.**

When students learn assembly first:
- ✅ They understand memory, registers, and the CPU
- ✅ High-level languages make sense (they see what compilers do)
- ✅ Debugging becomes logical, not magical
- ✅ They think like computer scientists, not just coders
- ✅ Complex topics (recursion, pointers, memory) are intuitive

After 6 weeks of assembly, BASIC feels **easy**. Students appreciate abstraction because they've lived without it.

---

### Complete Curriculum Package

**Everything a teacher needs to run this course successfully:**

#### ✅ **75 Complete Lesson Plans** (15 weeks × 5 days)
- Detailed 50-minute structured lessons
- Learning objectives aligned to CSTA standards
- Warm-ups, direct instruction, guided practice
- Independent practice at 3 difficulty levels
- Assessments and homework included
- Teacher notes and common pitfalls

#### ✅ **4 Major Projects with Full Rubrics**
- Week 3: Assembly Calculator
- Week 6: Assembly Game/Application  
- Week 10: BASIC Application
- Week 15: Capstone Integration Project
- Complete specifications, starter code, solutions
- Grading rubrics and troubleshooting guides

#### ✅ **Complete Assessment Package**
- 14 weekly quizzes (25 points each)
- Midterm exam (100 points)
- Final exam (200 points)
- **All answer keys included**
- Partial credit guidance
- Time-saving grading tips

#### ✅ **10 Practice Worksheets**
- Binary practice (60 problems)
- Code tracing exercises
- Debugging challenges
- Optimization problems
- All with complete answer keys

#### ✅ **10 Student Handouts**
- Assembly reference card (laminated)
- BASIC reference card (laminated)
- Binary conversion chart
- Memory map templates
- Program planning sheets
- Architecture posters (11×17")

#### ✅ **Comprehensive Teacher Guide**
- Setup and installation instructions
- Teaching strategies that work
- Differentiation for 3 ability levels
- Classroom management tips
- Extension activities
- Parent communication templates
- FAQ and troubleshooting

---

### Who Is This For?

**Perfect for:**
- High school computer science courses
- Middle school advanced STEM programs
- College prep CS courses
- Career and Technical Education (CTE)
- Students who "don't fit" traditional CS molds
- Visual and hands-on learners

**Especially effective for:**
- Students with learning differences
- Non-traditional learners
- Students who need to SEE how things work
- Classes that struggle with abstract concepts

---

### What Makes BasCAT Different?

#### **Visual Learning**
Students don't imagine the CPU—they **watch it work**. Real-time visualization makes abstract concepts concrete.

#### **Conscious Engagement**
Based on decades of experience teaching programming to students with diverse learning styles. Makes computational thinking observable.

#### **Complete Package**  
Not just software—a full curriculum. Print and teach Monday morning. No prep time required.

#### **Proven Pedagogy**
Assembly-first approach has 40+ years of success in professional training. Now adapted for education.

#### **Differentiation Built In**
Three tracks (foundational, standard, advanced) in every lesson. Works for diverse classrooms.

---

### Technical Specifications

**BasCAT Software:**
- Runs on Windows, Mac, Linux
- Web-based interface (modern browser required)
- Visual CPU with animated execution
- Assembly and BASIC modes
- Step-through debugging
- Memory and register visualization
- Compilation viewer (BASIC → Assembly)

**System Requirements:**
- 4GB RAM minimum
- Modern browser (Chrome, Firefox, Edge, Safari)
- Network/USB for file sharing (optional)
- Works on standard school computers

---

### Standards Alignment

**CSTA K-12 Computer Science Standards:**
- 3A-AP-13: Create prototypes using algorithms
- 3A-AP-16: Design and develop computational artifacts
- 3A-AP-17: Decompose problems systematically
- 3A-AP-21: Evaluate and refine computational artifacts
- 3A-CS-01: Explain how abstractions hide complexity
- 3A-CS-02: Compare levels of abstraction
- 3A-DA-09: Translate between data representations
- 3A-DA-10: Evaluate computational trade-offs

**Also suitable for:**
- AP Computer Science Principles preparation
- Career and Technical Education (CTE) pathways
- STEM enrichment programs
- Dual enrollment partnerships

---

### Investment

**Complete Curriculum Package Includes:**
- 48 comprehensive documents (~320 pages)
- BasCAT software license (per site)
- Teacher training materials
- Ongoing curriculum updates
- Implementation support

**Pricing:**
- Individual Teacher License: Contact for quote
- School/Department License: Contact for quote  
- District License: Contact for quote
- Pilot Program Pricing: Available for qualifying schools

---

### About Fragillidae Software

**Fragillidae Software** specializes in educational programming tools designed for students who don't fit traditional computer science molds. Founded by Chuck Finch, a developer with 40+ years of programming experience and extensive background in marine electronics and technical training.

Our philosophy: **Make abstract concepts concrete. Make computational thinking observable. Meet students where they are.**

**Company:** Fragillidae Software  
**Location:** 221 Walden Court, East Moriches, NY 11940  
**Contact:** Chuck Finch  
**Email:** info@fragillidaesoftware.com  
**Phone:** (631) 276-9068  

---

### Next Steps

**Interested in bringing BasCAT to your school or district?**

1. **Schedule a Demo** - See BasCAT in action, review curriculum materials
2. **Pilot Program** - Start with one class, evaluate results
3. **Professional Development** - Teacher training and support
4. **Full Implementation** - Roll out across department or district

**Contact us today to discuss your needs:**

📧 **info@fragillidaesoftware.com**  
📱 **(631) 276-9068**

---

### Testimonials

*"This is exactly what I've been looking for. My students finally understand how computers work instead of just memorizing syntax."*  
— Computer Science Teacher (name withheld for pilot program)

*"The visual aspect is incredible. Students who struggled with traditional CS suddenly 'get it' when they can see the CPU working."*  
— STEM Program Director (name withheld for pilot program)

---

**BasCAT: Building Computer Scientists from the Ground Up**

*Fragillidae Software - Educational Tools for Non-Traditional Learners*

---

**© 2024 Fragillidae Software. All rights reserved.**
**BasCAT and associated curriculum materials are proprietary products of Fragillidae Software.**
